export declare class UsersService {
    kakaoCode(): string;
    kakaoToken(body: any): void;
}
