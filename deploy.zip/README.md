# nest 초기파일

세팅해줄 것이 따로 없어서 사실 그냥 cli로 만들어주면 되긴한다.

그치만 hot reloading까지 해뒀고,, 이왕 initial settings를 모아두려 해서 그냥 해둔다!~~

.env설정 가능하게 해세팅해뒀구 (nestjs/config)

logger해주는 middleware설정 (morgan라이브러리를 사용하려 했으나 추후 확장할 필요가 있으니 그냥 따로 middleware로 사용하는걸로!)
